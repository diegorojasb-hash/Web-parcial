<?php
require_once 'models/PedidoModel.php';
require_once 'models/ProductoModel.php';

class PedidoController {
    private $pedidoModel;
    private $productoModel;

    public function __construct() {
        $this->pedidoModel = new PedidoModel();
        $this->productoModel = new ProductoModel();
    }

    // Maneja GET (?action=crud&edit=ID)
    public function index() {
        $productos = $this->productoModel->obtenerTodos();
        $pedidos = $this->pedidoModel->listarPedidos();
        $pedidoEditar = null;

        if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
            $pedidoEditar = $this->pedidoModel->obtenerPorId($_GET['edit']);
        }

        require 'views/crud_pedidos.php';
    }

    // Maneja POST para Crear o Actualizar
    public function guardar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'] ?? '';
            $producto_id = $_POST['producto_id'];
            $nombre = htmlspecialchars(trim($_POST['cliente_nombre']));
            $email = htmlspecialchars(trim($_POST['cliente_email']));
            $cantidad = (int) $_POST['cantidad'];
            $notas = htmlspecialchars(trim($_POST['notas']));

            if (!empty($id)) {
                $this->pedidoModel->actualizar($id, $producto_id, $nombre, $email, $cantidad, $notas);
                $tipo = 'actualizado';
            } else {
                $this->pedidoModel->crear($producto_id, $nombre, $email, $cantidad, $notas);
                $tipo = 'creado';
            }

            // Redirige a la página de Gracias pasando parámetros por GET
            header("Location: index.php?action=gracias&cliente=" . urlencode($nombre) . "&tipo=" . $tipo);
            exit;
        }
    }

    // Maneja GET (?action=eliminar&id=ID)
    public function eliminar() {
        if (isset($_GET['id']) && is_numeric($_GET['id'])) {
            $this->pedidoModel->eliminar($_GET['id']);
        }
        header("Location: index.php?action=crud");
        exit;
    }

    public function gracias() {
        $cliente = $_GET['cliente'] ?? 'Amante del Café';
        $tipo = $_GET['tipo'] ?? 'creado';
        require 'views/gracias.php';
    }
}