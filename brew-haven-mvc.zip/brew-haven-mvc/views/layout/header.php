<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brew Haven Coffee Co. | Specialty Coffee</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Librería 1: Swiper.js CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <!-- Librería 2 Adicional: Font Awesome + AOS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="bg-coffee-dark text-light">

<!-- SECCIÓN 1: NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top nav-glass">
    <div class="container">
        <a class="navbar-brand fw-bold font-serif text-gold" href="index.php">
            <i class="fas fa-mug-hot me-2"></i>BREW HAVEN
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuPrincipal">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menuPrincipal">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-3">
                <li class="nav-item"><a class="nav-link hover-link" href="index.php#inicio">Inicio</a></li>
                <li class="nav-item"><a class="nav-link hover-link" href="index.php#nosotros">Nosotros</a></li>
                <li class="nav-item"><a class="nav-link hover-link" href="index.php#menu">Popular Picks</a></li>
                <li class="nav-item"><a class="nav-link hover-link" href="index.php#beneficios">Beneficios</a></li>
                <li class="nav-item"><a class="nav-link hover-link" href="index.php#testimonios">Reseñas</a></li>
                <li class="nav-item">
                    <a class="btn btn-gold btn-sm px-3 rounded-pill" href="index.php?action=crud">
                        <i class="fas fa-clipboard-list me-1"></i> Pedidos (CRUD)
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>