<?php
require_once 'config/database.php';

class PedidoModel {
    private $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    public function listarPedidos() {
        $sql = "SELECT ped.*, prod.nombre AS producto_nombre, prod.precio 
                FROM pedidos ped 
                INNER JOIN productos prod ON ped.producto_id = prod.id 
                ORDER BY ped.id DESC";
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorId($id) {
        $stmt = $this->db->prepare("SELECT * FROM pedidos WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function crear($producto_id, $nombre, $email, $cantidad, $notas) {
        $sql = "INSERT INTO pedidos (producto_id, cliente_nombre, cliente_email, cantidad, notas) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$producto_id, $nombre, $email, $cantidad, $notas]);
    }

    public function actualizar($id, $producto_id, $nombre, $email, $cantidad, $notas) {
        $sql = "UPDATE pedidos 
                SET producto_id = ?, cliente_nombre = ?, cliente_email = ?, cantidad = ?, notas = ? 
                WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$producto_id, $nombre, $email, $cantidad, $notas, $id]);
    }

    public function eliminar($id) {
        $stmt = $this->db->prepare("DELETE FROM pedidos WHERE id = ?");
        return $stmt->execute([$id]);
    }
}